import {FastifyInstance} from "fastify";
import {getKeyAccountsHandler} from "../../v2-state/get_key_accounts/get_key_accounts.js";
import {addApiRoute, getRouteName} from "../../../helpers/functions.js";

export default function (fastify: FastifyInstance, opts: any, next) {

    // POST
    addApiRoute(fastify, 'POST', getRouteName(import.meta.filename), getKeyAccountsHandler, {
        description: 'get accounts by public key',
        summary: 'get accounts by public key',
        tags: ['accounts'],
        body: {
            type: 'object',
            properties: {"public_key": {description: 'public key', type: 'string'}},
            required: ["public_key"]
        },
        response: {
            200: {
                type: 'object',
                properties: {"account_names": {type: "array", items: {type: "string"}}}
            }
        }
    });
    next();
}
