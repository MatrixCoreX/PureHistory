import { BulkWriteResult, Collection, Db } from "mongodb";
import { ConnectionManager } from "../connections/manager.class.js";
import { Message } from "amqplib";
import { hLog } from "./common_functions.js";
import { IAccount } from "../../interfaces/table-account.js";
import { IProposal } from "../../interfaces/table-proposal.js";
import { IVoter } from "../../interfaces/table-voter.js";
import { IPermission } from "../../interfaces/table-permissions.js";
import { last } from "lodash";
import { stateUpdate } from './mongo-state.js';

export class MongoRoutes {

    cm: ConnectionManager;
    routes: Record<string, any> = {};
    private db?: Db;
    private accountsCollection?: Collection<IAccount>;
    private proposalsCollection?: Collection<IProposal>;
    private votersCollection?: Collection<IVoter>;
    private permissionsCollection?: Collection<IPermission>;

    constructor(connectionManager: ConnectionManager) {
        this.cm = connectionManager;
        this.cm.prepareMongoClient();
        if (this.cm.mongodbClient && this.cm.conn.mongodb) {
            this.db = this.cm.mongodbClient.db(`${this.cm.conn.mongodb.database_prefix}_${this.cm.chain}`);
            this.accountsCollection = this.db.collection('accounts');
            this.proposalsCollection = this.db.collection('proposals');
            this.votersCollection = this.db.collection('voters');
            this.permissionsCollection = this.db.collection('permissions');
            this.addRoutes();
            this.addDynamicRoutes();
        }
    }

    addRoutes() {

        this.routes['state'] = (payload: Message[], callback: (indexed_size?: number, error?: unknown) => void) => {

            const promises: Promise<any>[] = [];
            let totalIndexed = 0;

            // filter permission messages
            const permissionMessages = payload.filter((msg: Message) => {
                const headers = msg.properties.headers as any;
                return headers.type === 'permission';
            });

            if (permissionMessages.length > 0) {
                const operations = permissionMessages.map((msg: Message) => {
                    const data = JSON.parse(msg.content.toString()) as IPermission & { present: number };
                    if (data.present !== 0) {
                        return {
                            updateOne: {
                                filter: {
                                    account: data.owner,
                                    perm_name: data.name
                                },
                                update: {
                                    $set: {
                                        block_num: data.block_num,
                                        parent: data.parent,
                                        required_auth: data.auth,
                                        last_updated: data.last_updated
                                    }
                                },
                                upsert: true
                            }
                        };
                    } else {
                        return {
                            deleteOne: {
                                filter: {
                                    account: data.owner,
                                    perm_name: data.name
                                }
                            }
                        };
                    }
                });

                const p = this.permissionsCollection?.bulkWrite(operations, { ordered: false })
                    .then(() => {
                        totalIndexed += permissionMessages.length;
                    })
                    .catch(reason => {
                        hLog('error', 'mongo-routes', 'state/permission', reason);
                        throw reason;
                    });

                if (p) promises.push(p);
            }

            const permissionLinkMessages = payload.filter((msg: Message) => {
                const headers = msg.properties.headers as any;
                return headers.type === 'permission_link';
            });

            if (permissionLinkMessages.length > 0) {
                const operations = permissionLinkMessages.map((msg: Message) => {
                    const data = JSON.parse(msg.content.toString()) as IPermission & { present: number };
                    if (data.present !== 0) {
                        return {
                            updateOne: {
                                filter: {
                                    account: data.account,
                                    perm_name: data.permission
                                },
                                update: {
                                    $set: {
                                        block_num: data.block_num,
                                        last_updated: data['@timestamp']
                                    },
                                    $addToSet: {
                                        linked_actions: {
                                            account: data.code,
                                            action: data.action
                                        }
                                    }
                                },
                                upsert: true
                            }
                        };
                    } else {
                        return {
                            updateOne: {
                                filter: {
                                    account: data.account,
                                    perm_name: data.permission
                                },
                                update: {
                                    $pull: {
                                        linked_actions: {
                                            account: data.code,
                                            action: data.action
                                        } as any
                                    }
                                },
                                upsert: false
                            }
                        };
                    }
                });

                const p = this.permissionsCollection?.bulkWrite(operations, { ordered: false })
                    .then(() => {
                        totalIndexed += permissionLinkMessages.length;
                    })
                    .catch(reason => {
                        hLog('error', 'mongo-routes', 'state/permission_link', reason);
                        throw reason;
                    });

                if (p) promises.push(p);
            }

            if (promises.length > 0) {
                Promise.all(promises).then(() => {
                    callback(totalIndexed);
                }, error => callback(0, error));
            } else {
                hLog('Unexpected state message without permissions or permission_links');
                callback(0);
            }
        };

        this.routes['table-accounts'] = (payload: Message[], callback: (size?: number, error?: unknown) => void) => {
            const operations = payload.map(msg => {
                const data = JSON.parse(msg.content.toString());
                return stateUpdate({code: data.code, scope: data.scope, symbol: data.symbol}, data);
            });
            this.accountsCollection!.bulkWrite(operations, {ordered: false})
                .then(() => callback(payload.length), error => callback(0, error));
        };

        this.routes['table-proposals'] = (payload: Message[], callback: (size?: number, error?: unknown) => void) => {
            const operations = payload.map(msg => {
                const data = JSON.parse(msg.content.toString());
                return {updateOne: {filter: {proposal_name: data.proposal_name, proposer: data.proposer},
                    update: {$set: data}, upsert: true}};
            });
            this.proposalsCollection!.bulkWrite(operations, {ordered: false})
                .then(() => callback(payload.length), error => callback(0, error));
        };

        this.routes['table-voters'] = (payload: Message[], callback: (size?: number, error?: unknown) => void) => {
            const operations = payload.map(msg => {
                const data = JSON.parse(msg.content.toString());
                return stateUpdate({voter: data.voter}, data);
            });
            this.votersCollection!.bulkWrite(operations, {ordered: false})
                .then(() => callback(payload.length), error => callback(0, error));
        };
    }

    private addDynamicRoutes() {
        this.routes['dynamic-table'] = (payload: Message[], callback: (indexed_size?: number, error?: unknown) => void) => {
            const groupedOps = new Map<string, any[]>();
            payload.forEach((msg: Message) => {
                const delta = JSON.parse(msg.content.toString()) as any;
                const headers = msg.properties.headers as any;

                const op = {};

                if (headers.present === 1) {
                    op['updateOne'] = {
                        filter: {
                            '@scope': delta.scope,
                            '@pk': delta.primary_key
                        },
                        update: {
                            $set: {
                                '@scope': delta.scope,
                                '@pk': delta.primary_key,
                                '@payer': delta.payer,
                                '@block_num': delta.block_num,
                                '@block_time': delta['@timestamp'],
                                '@block_id': delta['block_id'],
                                ...delta.data
                            }
                        },
                        upsert: true
                    };
                } else {
                    op['deleteOne'] = {
                        filter: {
                            '@scope': delta.scope,
                            '@pk': delta.primary_key
                        }
                    };
                }

                const collection = headers.code + '-' + headers.table;
                const col = groupedOps.get(collection);
                if (col) {
                    col.push(op);
                } else {
                    groupedOps.set(collection, [op]);
                }
                // hLog(msg.properties.headers, delta);
            });

            const promises: Promise<BulkWriteResult>[] = [];

            groupedOps.forEach((value, key) => {
                if (this.db) {
                    promises.push(this.db.collection(key).bulkWrite(value, { ordered: false }))
                }
            });

            Promise.all(promises).then(() => {
                callback(payload.length);
            }, error => callback(0, error));
        }

    }
}
